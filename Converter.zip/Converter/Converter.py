import math


# BY: Alex Pokorskiy
# Creation Date: 05/06/2023

class TempCnvrt:
    # Formulas used in this
    # "F = (input × 9/5) + 32 = output"
    # "K = input + 273.15"
    # "C = (input-32) (5/9)"
    # "K = (input-32) (5/9) + 273.15"
    # "F = (K-273.15) (9/5) + 32"
    # "C = K - 273.15"

    def __init__(self):
        pass

    def ctof(self, val):
        self.val = val
        return round((self.val * (9 / 5)) + 32, 2)

    def ctok(self, val):
        self.val = val
        return round(self.val + 273.15, 2)

    def ftoc(self, val):
        self.val = val
        return round((self.val - 32) * (5 / 9), 2)

    def ftok(self, val):
        self.val = val
        return round((self.val - 32) * (5 / 9) + 273.15, 2)

    def ktoc(self, val):
        self.val = val
        return round(self.val - 273.15, 2)

    def ktof(self, val):
        self.val = val
        return round((self.val - 273.15) * (9 / 5) + 32, 2)


class VolumeCnvrt:
    def __init__(self):
        pass

    def atob(self, val, c, s):
        self.val = val
        self.c = c
        self.s = s

        for i_id, i_val in vol_table.items():
            for k in i_val:
                if k == c:
                    self.c = i_val[k]
            for i in i_val:
                if i == s:
                    self.s = i_val[i]

        x = val * self.s
        return x / self.c


class MassCnvrt:
    def __init__(self):
        pass

    def massconv(self, val, c, s):
        self.val = val
        self.c = c
        self.s = s

        for i_id, i_val in mass_table.items():
            for k in i_val:
                if k == c:
                    self.c = i_val[k]
            for i in i_val:
                if i == s:
                    self.s = i_val[i]

        x = val * self.s
        return x / self.c


vol_table = {"acre-foot": {"acft": 1233.481838},
             "barrel (Imperial)": {"bl": 0.16365924},
             "bushel (Imperial)": {"bu": 0.03636872},
             "cord (firewood)": {"cord": 3.624556364},
             "cubic foot": {"ft3": 0.028316847},
             "cubic centimeter": {"cn3": 0.000001},
             "cubic meter": {"m3": 1},
             "cubic mile": {"mi3": 4168181825},
             "cubic yard": {"yd3": 0.764554858},
             "cup (breakfast)": {"c": 0.000236588},
             "ounce (Imperial fluid)": {"oz": 2.95735E-05},
             "gallon (Imperial)": {"gal": 0.00454609},
             "gill (Imperial)": {"gi": 0.000142065},
             "hogshead (Imperial)": {"hhd": 0.32731848},
             "liter": {"l": 0.001},
             "milliliter": {"ml": 0.000001},
             "pint (Imperial)": {"pt": 0.000568261},
             "quart (Imperial)": {"qt": 0.001136523},
             "tablespoon (Imperial)": {"tbsp": 1.77582E-05},
             "teaspoon (Imperial)": {"tsp": 5.91939E-06},
             "cubic inch": {"in3": 1.63871E-05},
             "peck (Imperial)": {"pk": 0.00909218}}

mass_table = {"milligram": {"mg": 0.001},
              "kilogram": {"kg": 1000},
              "gram": {"g": 1},
              "carat (metric)": {"ct": 0.02},
              "point (metric)": {"pt": 0.002},
              "dram (avdp)": {"dr": 1.771845195},
              "grain (metric)": {"gr": 0.05},
              "megagram": {"Mg": 1000000},
              "microgram": {"ug": 0.001},
              "ounce (avdp)": {"oz": 28.34952313},
              "pennyweight": {"dwt": 1.55517384},
              "pound (metric)": {"lb": 500},
              "slug": {"slug": 0.02},
              "stone": {"st": 6350.29318},
              "ton (long)": {"ltn": 1016046.909},
              "ton (short)": {"shtn": 907184.74},
              "ton (metric)": {"tn": 1000000}}


def converttemp():
    temp = TempCnvrt()
    frm = None
    print("==========================================================")
    print("Available conversion units: \n C - Celsius \n F - Fahrenheit \n K - Kelvin")

    while frm not in ['C', 'F', 'K']:
        val = 0
        frm = input("Please select a unit to convert from: :")

        if frm.upper() == 'C':
            to = input("Please select a unit to convert to: ")

            if to.upper() == 'F':
                print("{} to {} selected".format(frm.upper(), to.upper()))
                val = int(input("Enter the calcualted value"))
                print(str(temp.ctof(val)) + ' ' + to)
                break
            elif to.upper() == 'K':
                print("{} to {} selected".format(frm.upper(), to.upper()))
                val = int(input("Enter the calcualted value"))
                print(str(temp.ctok(val)) + ' ' + to)
                break
            else:
                print("Not in scop value, try again")

        elif frm.upper() == 'F':
            to = input("Please select a unit to convert to: ")
            if to.upper() == 'C':
                print("{} to {} selected".format(frm.upper(), to.upper()))
                val = int(input("Enter the calcualted value"))
                print(str(temp.ftoc(val)) + ' ' + to)
                break

            elif to.upper() == 'K':
                print("{} to {} selected".format(frm.upper(), to.upper()))
                val = int(input("Enter the calcualted value"))
                print(str(temp.ftok(val)) + ' ' + to)
                break
            else:
                print("Not in scop value, try again")

        elif frm.upper() == 'K':
            to = input("Please select a unit to convert to: ")
            if to.upper() == 'F':
                print("{} to {} selected".format(frm.upper(), to.upper()))
                val = int(input("Enter the calcualted value"))
                print((temp.ktof(val)) + ' ' + to)
                break
            elif to.upper() == 'C':
                print("{} to {} selected".format(frm.upper(), to.upper()))
                val = int(input("Enter the calcualted value"))
                print(str(temp.ktof(val)) + ' ' + to)

                break
            else:
                print("Not in scop value, try again")
        else:
            print("Not in scop value, try again")


def convertvol():
    vol = VolumeCnvrt()
    itms = {}
    frm = ''
    to = ''
    conv = ''

    print("==========================================================")
    print("Available measurement units: ")
    for i_id, i_val in vol_table.items():
        for i in i_val:
            print("|" + i + " - " + i_id.capitalize())

    while frm not in itms:
        print("==========================================================")
        frm = input("Please enter the Unit to convert from: ")
        value = input("Please input the value: ")

        while to not in itms:
            to = input("Please enter the Unit to convert to: ")
            print("==========================================================")
            conv = str(vol.atob(int(value), frm, to)) + ' ' + to.upper()

    return conv


def convertmass():
    mass = MassCnvrt()
    itms = {}
    frm = ''
    to = ''
    print("==========================================================")
    print("Available measurement units: ")
    for i_id, i_val in mass_table.items():
        for k in i_val:
            itms.add(k)
            print("|" + k + " - " + i_id.capitalize())

    while frm not in itms:
        print("==========================================================")
        frm = input("Please enter the Unit to convert from: ")
        value = input("Please input the value: ")

        while to not in itms:
            to = input("Please enter the Unit to convert to: ")
            print("==========================================================")
            conv = str(mass.massconv(int(value), to, frm)) + ' ' + to.upper()
            return conv


def selections():
    int_choice = 'w'

    while int_choice not in ["y", "n"]:
        int_choice = input("Do you wish to go back to main menu [y,n]: ")

        if int_choice not in ["y", "n"]:
            print("Invlid choice, try again. Please pick y or n")

    if int_choice == "y":
        return True
    else:
        return False


def menu():
    ans = None
    while ans not in [1, 2, 3]:
        print("Please select one of the following options: ")
        print("1. Convert Temperature")
        print("2. Convert Volume")
        print("3. Convert Mass")
        ans = int(input("Enter answer: "))

    return ans


active = True
brs = None
print("=======================================================")
print("               Welcome to the conversion               ")
print("=======================================================")

while active:

    brs = menu()

    if brs == 1:
        converttemp()
    elif brs == 2:
        convertvol()
    elif brs == 3:
        convertmass()

    if not selections():
        print("Goodbye :)")
        print("Made by Alex Pokorskiy")
        active = False
